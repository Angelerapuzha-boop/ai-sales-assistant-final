"""
AI Sales Assistant — Flask 3.1 Application
Single entry point: python app.py
"""
import logging
import os
from flask import Flask, render_template, jsonify

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("sales")

# ── Create Flask app ─────────────────────────────────────────────────────────
app = Flask(__name__, template_folder="templates", static_folder="static")

from config import SECRET_KEY, PORT, DEBUG
app.secret_key = SECRET_KEY

# ── Register API blueprint ────────────────────────────────────────────────────
from routes_api import api as api_bp
app.register_blueprint(api_bp)

# ── Frontend route ────────────────────────────────────────────────────────────
@app.route("/")
@app.route("/<path:_>")
def index(_=None):
    return render_template("index.html")

# ── Health check (used by Docker + status panel) ──────────────────────────────
@app.get("/health")
def health():
    from config import GROQ_API_KEY, TWILIO_SID, TWILIO_TOKEN, BLAND_API_KEY, GMAIL_EMAIL, GMAIL_PASSWORD
    from database import q
    try:
        cos = len(q("SELECT id FROM companies"))
        db_ok = True
    except Exception:
        cos, db_ok = 0, False
    return jsonify({
        "status":  "healthy" if db_ok else "degraded",
        "database": db_ok,
        "companies": cos,
        "groq":    bool(GROQ_API_KEY),
        "twilio":  bool(TWILIO_SID and TWILIO_TOKEN),
        "bland":   bool(BLAND_API_KEY),
        "gmail":   bool(GMAIL_EMAIL and GMAIL_PASSWORD),
    })

# ── Global error handlers (never show raw tracebacks to users) ────────────────
@app.errorhandler(404)
def not_found(e):
    if "api" in str(getattr(e, "description", "")):
        return jsonify({"ok": False, "error": "Endpoint not found"}), 404
    return render_template("index.html")   # SPA — return index for all non-API 404s

@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"ok": False, "error": "Method not allowed"}), 405

@app.errorhandler(500)
def server_error(e):
    logger.error(f"500: {e}")
    return jsonify({"ok": False, "error": "Internal server error"}), 500

# ── Startup ───────────────────────────────────────────────────────────────────
def startup():
    from database import init_db
    init_db()
    logger.info("✅ Database ready")
    from scheduler import start
    start()
    logger.info("✅ Scheduler started")
    logger.info(f"🚀 AI Sales Assistant running at http://localhost:{PORT}")
    logger.info(f"   Default login: admin@salesai.com / Admin@123456")

if __name__ == "__main__":
    startup()
    app.run(host="0.0.0.0", port=PORT, debug=DEBUG, use_reloader=False)
