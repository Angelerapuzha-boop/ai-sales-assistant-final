#!/usr/bin/env python3
"""
start.py — AI Sales Assistant launcher
Run with:  python start.py
Opens at:  http://localhost:5000
Login:     admin@salesai.com  /  Admin@123456
"""
import sys
import os
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
sys.path.insert(0, HERE)

REQUIRED = {"Flask": "flask", "PyJWT": "jwt", "requests": "requests", "pandas": "pandas"}

print("=" * 56)
print("  AI Sales Assistant — Startup Check")
print("=" * 56)

# ── 1. Python version ────────────────────────────────────────
major, minor = sys.version_info.major, sys.version_info.minor
print(f"\n[1] Python {major}.{minor}", end=" ")
if major < 3 or (major == 3 and minor < 9):
    print("❌  Need Python 3.9+")
    print("    Download: https://www.python.org/downloads/")
    sys.exit(1)
print("✅")

# ── 2. Dependencies ──────────────────────────────────────────
print("[2] Checking packages...")
missing = []
for name, mod in REQUIRED.items():
    try:
        __import__(mod)
        print(f"    ✅ {name}")
    except ImportError:
        print(f"    ❌ {name} — not installed")
        missing.append(name)

if missing:
    print(f"\n    Installing missing packages...")
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install"] + missing,
            stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
        )
        print("    ✅ Installed!")
    except Exception as e:
        print(f"    ❌ Auto-install failed: {e}")
        print(f"    Run manually: pip install {' '.join(missing)}")
        sys.exit(1)

# ── 3. Templates ─────────────────────────────────────────────
print("[3] Checking templates...", end=" ")
tmpl = os.path.join(HERE, "templates", "index.html")
if not os.path.exists(tmpl):
    print("❌  templates/index.html missing!")
    sys.exit(1)
print("✅")

# ── 4. Database dir ──────────────────────────────────────────
print("[4] Checking data directory...", end=" ")
os.makedirs(os.path.join(HERE, "data"), exist_ok=True)
print("✅")

# ── 5. Port check ────────────────────────────────────────────
import socket
PORT = int(os.environ.get("PORT", 5000))
print(f"[5] Checking port {PORT}...", end=" ")
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("0.0.0.0", PORT))
        print("✅  Free")
    except OSError:
        print(f"⚠️   Port {PORT} in use — trying {PORT+1}")
        PORT = PORT + 1
        os.environ["PORT"] = str(PORT)

# ── 6. Launch ────────────────────────────────────────────────
print()
print("=" * 56)
print(f"  🚀  Starting at  http://localhost:{PORT}")
print(f"  🔑  Login:  admin@salesai.com  /  Admin@123456")
print(f"  ⛔  Stop:   Ctrl + C")
print("=" * 56)
print()

from app import app, startup
startup()
app.run(host="0.0.0.0", port=PORT, debug=False, use_reloader=False)
