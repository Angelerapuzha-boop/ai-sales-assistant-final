"""
AI Sales Assistant — Flask 3.1 Application
Local:  python start.py
Render: gunicorn app:app
"""
import logging
import os
from flask import Flask, render_template, jsonify

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("sales")

app = Flask(__name__, template_folder="templates", static_folder="static")

from config import SECRET_KEY, PORT, DEBUG
app.secret_key = SECRET_KEY

from routes_api import api as api_bp
app.register_blueprint(api_bp)

@app.route("/")
@app.route("/<path:_>")
def index(_=None):
    return render_template("index.html")

@app.get("/health")
def health():
    from config import GROQ_API_KEY, TWILIO_SID, TWILIO_TOKEN, BLAND_API_KEY, GMAIL_EMAIL, GMAIL_PASSWORD
    from database import q
    try:
        cos = len(q("SELECT id FROM companies"))
        db_ok = True
    except Exception:
        cos, db_ok = 0, False
    return jsonify({
        "status":  "healthy" if db_ok else "degraded",
        "database": db_ok,
        "companies": cos,
        "groq":    bool(GROQ_API_KEY),
        "twilio":  bool(TWILIO_SID and TWILIO_TOKEN),
        "bland":   bool(BLAND_API_KEY),
        "gmail":   bool(GMAIL_EMAIL and GMAIL_PASSWORD),
    })

@app.errorhandler(404)
def not_found(e):
    return render_template("index.html")

@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"ok": False, "error": "Method not allowed"}), 405

@app.errorhandler(500)
def server_error(e):
    logger.error(f"500: {e}")
    return jsonify({"ok": False, "error": "Internal server error"}), 500

# Run startup (DB init + scheduler) on first request
_started = False
@app.before_request
def _startup():
    global _started
    if not _started:
        _started = True
        from database import init_db
        init_db()
        from scheduler import start
        start()
        logger.info("✅ App initialised")

if __name__ == "__main__":
    from database import init_db
    from scheduler import start
    init_db()
    start()
    port = int(os.environ.get("PORT", 5000))
    logger.info(f"🚀 Running at http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)
